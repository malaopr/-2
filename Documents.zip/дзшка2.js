class TodoApp {
    constructor() {
        this.tasks = JSON.parse(localStorage.getItem('tasks')) || [];
        this.taskIdCounter = Math.max(0, ...this.tasks.map(task => task.id)) + 1;
        this.currentFilter = 'all';
        
        this.initializeElements();
        this.renderTasks();
        this.attachEventListeners();
    }

    initializeElements() {
        this.taskInput = document.getElementById('taskInput');
        this.addTaskBtn = document.getElementById('addTaskBtn');
        this.taskList = document.getElementById('taskList');
        this.taskCounter = document.getElementById('taskCounter');
        this.filterInputs = document.querySelectorAll('input[name="filter"]');
    }

    attachEventListeners() {
        this.addTaskBtn.addEventListener('click', () => this.addTask());
        this.taskInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') this.addTask();
        });
        this.taskInput.addEventListener('input', () => this.updateAddButtonState());
        
        this.filterInputs.forEach(input => {
            input.addEventListener('change', (e) => {
                this.currentFilter = e.target.id;
                this.renderTasks();
            });
        });
    }

    updateAddButtonState() {
        const text = this.taskInput.value.trim();
        this.addTaskBtn.disabled = !text || this.addTaskBtn.classList.contains('loading');
    }

    async addTask() {
        const text = this.taskInput.value.trim();
        if (!text || this.addTaskBtn.classList.contains('loading')) return;

        this.setLoadingState(this.addTaskBtn, true);
        this.taskInput.disabled = true;

        try {
            await this.simulateServerRequest(2000, 5000);
            
            const task = {
                id: this.taskIdCounter++,
                text: text,
                completed: false,
                createdAt: new Date().toISOString()
            };
            
            this.tasks.push(task);
            this.saveToLocalStorage();
            this.renderTasks();
            this.taskInput.value = '';
        } catch (error) {
            console.error('Ошибка при добавлении задачи:', error);
            alert('🍃 Произошла ошибка при добавлении задачи. Попробуйте снова.');
        } finally {
            this.setLoadingState(this.addTaskBtn, false);
            this.taskInput.disabled = false;
            this.updateAddButtonState();
            this.taskInput.focus();
        }
    }

    async toggleTask(taskId) {
        const task = this.tasks.find(t => t.id === taskId);
        if (!task) return;

        const taskElement = document.querySelector(`[data-task-id="${taskId}"]`);
        if (taskElement.classList.contains('task-loading')) return;

        taskElement.classList.add('task-loading');
        const deleteBtn = taskElement.querySelector('.delete-btn');
        if (deleteBtn) deleteBtn.disabled = true;

        try {
            await this.simulateServerRequest(2000, 5000);
            
            task.completed = !task.completed;
            this.saveToLocalStorage();
            this.renderTasks();
        } catch (error) {
            console.error('Ошибка при изменении статуса задачи:', error);
            alert('🍃 Произошла ошибка при изменении статуса задачи. Попробуйте снова.');
        } finally {
            taskElement.classList.remove('task-loading');
            if (deleteBtn) deleteBtn.disabled = false;
        }
    }

    async deleteTask(taskId) {
        const task = this.tasks.find(t => t.id === taskId);
        if (!task) return;

        const taskElement = document.querySelector(`[data-task-id="${taskId}"]`);
        if (taskElement.classList.contains('delete-loading')) return;

        const deleteBtn = taskElement.querySelector('.delete-btn');
        this.setLoadingState(deleteBtn, true);
        taskElement.querySelector('.task-checkbox').disabled = true;

        try {
            await this.simulateServerRequest(2000, 5000);
            
            taskElement.classList.add('removing');
            
            await new Promise(resolve => {
                taskElement.addEventListener('animationend', resolve, { once: true });
            });

            this.tasks = this.tasks.filter(t => t.id !== taskId);
            this.saveToLocalStorage();
            this.renderTasks();
        } catch (error) {
            console.error('Ошибка при удалении задачи:', error);
            alert('🍃 Произошла ошибка при удалении задачи. Попробуйте снова.');
            this.setLoadingState(deleteBtn, false);
            taskElement.querySelector('.task-checkbox').disabled = false;
        }
    }

    simulateServerRequest(minDelay = 2000, maxDelay = 5000) {
        const delay = Math.random() * (maxDelay - minDelay) + minDelay;
        return new Promise((resolve, reject) => {
            setTimeout(() => {
                if (Math.random() < 0.05) {
                    reject(new Error('Серверная ошибка'));
                } else {
                    resolve();
                }
            }, delay);
        });
    }

    setLoadingState(button, isLoading) {
        if (isLoading) {
            button.classList.add('loading');
            button.disabled = true;
        } else {
            button.classList.remove('loading');
            button.disabled = false;
        }
    }

    getFilteredTasks() {
        switch (this.currentFilter) {
            case 'completed':
                return this.tasks.filter(task => task.completed);
            case 'pending':
                return this.tasks.filter(task => !task.completed);
            default:
                return this.tasks;
        }
    }

    renderTasks() {
        const filteredTasks = this.getFilteredTasks();
        
        if (filteredTasks.length === 0) {
            this.taskList.innerHTML = '<div class="empty-state">🍃 Пока нет задач</div>';
        } else {
            this.taskList.innerHTML = filteredTasks.map(task => `
                <li class="task-item ${task.completed ? 'completed' : ''}" data-task-id="${task.id}">
                    <input 
                        type="checkbox" 
                        class="task-checkbox" 
                        ${task.completed ? 'checked' : ''}
                        onchange="app.toggleTask(${task.id})"
                    >
                    <span class="task-text ${task.completed ? 'completed' : ''}">${this.escapeHtml(task.text)}</span>
                    <button class="delete-btn" onclick="app.deleteTask(${task.id})">
                        <span class="delete-text">🗑️</span>
                        <div class="delete-spinner">🌿</div>
                    </button>
                </li>
            `).join('');
        }
        
        this.updateStats();
    }

    updateStats() {
        const total = this.tasks.length;
        const completed = this.tasks.filter(task => task.completed).length;
        const pending = total - completed;
        
        let message = `🌿 Всего задач: ${total}`;
        if (completed > 0) message += ` | ✅ Выполнено: ${completed}`;
        if (pending > 0) message += ` | ⏳ Осталось: ${pending}`;
        
        this.taskCounter.textContent = message;
    }

    saveToLocalStorage() {
        localStorage.setItem('tasks', JSON.stringify(this.tasks));
    }

    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
}

const app = new TodoApp();